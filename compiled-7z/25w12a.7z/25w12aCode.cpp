#include<bits/stdc++.h>
using namespace std;
void pause() {
    cout << "Press any key to continue...";
    getch();
}
void calculator();
void randomNumber();
void choose() {
    system("cls");
    cout << "Welcome to Siprca Tool Box!\n";
    cout << "Please choose one:\n";
    cout << "1.Calculator\n";
    cout << "2.Random number generation\n";
    cout << "3.Get tips\n";
    cout << "4.Exit.\n";
    
    cout << "Please input function corresponding number:\n";
    char chs;
    chs = getch();
    switch(chs) {
        case '1':
            system("cls");
            calculator();
        case '2':
            system("cls");
            randomNumber();
        case '3':
            system("cls");
            //randomNumber();
            cout << "Developing...\n";
            cout << "May be implemented in the next version.\n";
            pause();
            choose();
        case '4':
            cout << "Exiting...\n";
            exit(0);
        default:
            cout << "Invalid input. Please try again.\n";
            choose();
    }
}
int main() {
    choose();
    return 0;
}
void calculator() {
    cout << "Please enter the formula:\n";
    long long a,b;
    char ch;
    scanf("%lld %c %lld",&a,&ch,&b);
    if(ch == '+') {
        system("cls");
        long long int ans;
        ans = a + b;
        printf("%lld %c %lld = %lld\n",a,ch,b,ans);
        pause();
    } else if(ch == '-') {
        system("cls");
        long long int ans;
        ans = a - b;
        printf("%lld %c %lld = %lld\n",a,ch,b,ans);
        pause();
    } else if(ch == '*') {
        system("cls");
        long long int ans;
        ans = a * b;
        printf("%lld %c %lld = %lld\n",a,ch,b,ans);
        pause();
    } else if(ch == '/') {
        system("cls");
        long long int ans;
        ans = a / b;
        long long int y = a - b * ans;
        printf("%lld %c %lld = %lld ...... %lld\n",a,ch,b,ans,y);
        pause();
    } else if(ch == '^') {
        system("cls");
        long long int ans;
        ans = pow(a,b);
        printf("%lld %c %lld = %lld\n",a,ch,b,ans);
        pause();
    } else if(ch == '#') {
        system("cls");
        printf("%lld %c = %lf\n",a,ch,sqrt(a));
        cout << "Press any key to continue...";
        pause();
    }
    choose();
}

void randomNumber() {
    int mx;
    int mi;
    int rd;
    struct timeb timeSeed;
    
    cout << "Please choose maximum number...\n";
    cin >> mx;
    cout << "\nPlease choose minimum number...\n";
    cin >> mi;
    system("cls");
    
    //Get random number.
    ftime(&timeSeed);
    srand(time(NULL) + timeSeed.millitm);
    rd = (rand() % (mx - mi + 1)) + mi;

    cout << "Random number is: " << rd << ".\n";
    pause();
    choose();
}